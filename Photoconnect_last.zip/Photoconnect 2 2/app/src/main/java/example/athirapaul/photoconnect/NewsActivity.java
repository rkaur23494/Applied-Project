package example.athirapaul.photoconnect;



import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class NewsActivity extends Activity {
WebView mywebview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        mywebview = (WebView)findViewById(R.id.webView);
        mywebview.setWebViewClient(new MyBrowser());//to bring the browser inside the application
        mywebview.getSettings().setJavaScriptEnabled(true);
        mywebview.loadUrl("https://petapixel.com/tag/api/");
    }
    public class MyBrowser extends WebViewClient{
        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            mywebview.loadUrl(url);
            return true;
        }
    }
}



