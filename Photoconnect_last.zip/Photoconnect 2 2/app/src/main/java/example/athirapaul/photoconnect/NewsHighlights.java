package example.athirapaul.photoconnect;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

//public class NewsHighlights extends AppCompatActivity {
//public static  TextView data;
//Button click;
////WebView webView;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_news_highlights);
//click = (Button)findViewById(R.id.button);
//data = (TextView)findViewById(R.id.textView);
////webView = (WebView)findViewById(R.id.webView);
////        Bundle bundle = getIntent().getExtras();
////        String try1 = bundle.getString("radiobutton2");
////        Log.i("Wedding","final");
//
//
////        taskdata task = new taskdata();
////        task.execute("https://petapixel.com/?s=&year=&monthnum=&category_name="+ try1);
////        Log.i("test","entered");
////
//
//        click.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//taskdata task = new taskdata();
//task.execute();
//                webView.setWebViewClient(new NewsActivity.MyBrowser());//to bring the browser inside the application
//                webView.getSettings().setJavaScriptEnabled(true);
//                webView.loadUrl("https://petapixel.com/tag/api/");
//            }
//            public class MyBrowser extends WebViewClient {
//                @SuppressWarnings("deprecation")
//                @Override
//                public boolean shouldOverrideUrlLoading(WebView view, String url) {
//                    webView.loadUrl(url);
//                    return true;
//                }
//
//            }
//        });
//    }


//    public  class taskdata extends AsyncTask<String,Void,Void>{
//        String data = "";
//        @Override
//        protected Void doInBackground(String... urls) {
//
//
//            try {
//                String value = "api";
//                URL url = new URL("https://petapixel.com/tag?="+ value);
//                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
//
//                InputStream inputStream = urlConnection.getInputStream();
//                BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(inputStream));
//                String datanews = "";
//                while(datanews != null) {
//                    datanews = bufferedreader.readLine();
//                    data += datanews;
//
//                }
//
//
//            }
//            catch (MalformedURLException e) {
//                e.printStackTrace();
//            }
//            catch (IOException e) {
//                e.printStackTrace();
//            }
//            return  null;
//
//            }
//
//
//        @Override
//        protected void onPostExecute(Void aVoid) {
//            super.onPostExecute(aVoid);
//NewsHighlights.data.setText(this.data);
//
//            try {
//                JSONObject jsonObject = new JSONObject(data);
//
//                Log.i("tt",data);
//
//
//            }
//            catch (JSONException e){
//                e.printStackTrace();
//
//            }
//        }
//
//    }
//}
